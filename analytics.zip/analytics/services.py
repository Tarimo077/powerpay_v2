from sales.models import Sale
from customers.models import Customer
from devices.models import DeviceInfo, DeviceData

from django.db.models import Sum, Count, Avg
from django.utils import timezone


def customer_device_analytics(
    organization=None
):

    sales = Sale.objects.select_related(
        "customer"
    )

    if organization:
        sales = sales.filter(
            organization=organization
        )


    results = []


    for sale in sales:


        customer = sale.customer


        # Find linked device
        device = DeviceInfo.objects.filter(
            deviceid=sale.product_serial_number
        ).first()


        device_data = DeviceData.objects.none()


        if device:

            device_data = DeviceData.objects.filter(
                deviceid=device.deviceid
            )


        total_kwh = device_data.aggregate(
            total=Sum("kwh")
        )["total"] or 0


        readings = device_data.count()


        avg_kwh = device_data.aggregate(
            avg=Avg("kwh")
        )["avg"] or 0



        results.append({

            # Customer data
            "customer_name": customer.name,
            "phone": customer.phone_number,
            "county": customer.county,
            "location": customer.location,


            # Sale data
            "product": sale.product_name,
            "product_type": sale.product_type,
            "purchase_mode": sale.purchase_mode,
            "sales_rep": sale.sales_rep,
            "registration_date": sale.registration_date,


            # Device data
            "device_id": device.deviceid if device else None,
            "device_active": device.active if device else False,

            # Energy analytics
            "total_kwh": round(total_kwh,2),
            "readings": readings,
            "average_kwh": round(avg_kwh,3),

        })


    return results