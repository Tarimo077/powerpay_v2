from django.shortcuts import render
from .services import customer_device_analytics
from organizations.models import Organization


def customer_device_dashboard(request):

    organization_id = request.GET.get(
        "organization"
    )


    organization = None


    if organization_id:
        organization = Organization.objects.get(
            id=organization_id
        )


    data = customer_device_analytics(
        organization
    )


    context = {

        "analytics": data,

        "organizations":
            Organization.objects.all(),

    }


    return render(
        request,
        "analytics/customer_device_dashboard.html",
        context
    )